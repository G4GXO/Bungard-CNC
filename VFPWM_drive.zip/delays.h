// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Buttons Header
//
#ifndef DELAYS_H
#define	DELAYS_H

// Defines

// Declarations

// Prototypes
void delay_us(unsigned int);
void delay_ms(unsigned int);
void debounce();
void pause();

#endif	/* DELAYS_H */

