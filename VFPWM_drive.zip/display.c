// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Display Functions
#include <xc.h>
#include "main.h"
#include "input_capture.h"
#include "speed_ramps.h"
#include "analogues.h"
#include "lcd.h"
#include "delays.h"
#include "display.h"                    // Header file

// Convert a 16 bit binary integer value into a 5 digit decimal string
//
unsigned int bin_n;                     // Binary integer input
unsigned char bcd_n[5];					// 5 digit BCD output

void bin2bcd(int bin_n) {
unsigned int i;
unsigned int kb;
	kb=10000;
	   	for (i=4; i>0; i--){	
			bcd_n[i]=0;                 // Zero the results registers
				while(bin_n>=kb){       //
					bin_n=bin_n-kb;     // Subtract decade from the input number.
					++bcd_n[i];         // Increment results value on each successful subtraction 
					}
			kb=kb/10;                   // Next decade
			bcd_n[i]=bcd_n[i]|0x30;     // Add in ASCII offset
		}                               //
		bcd_n[0]=bin_n|0x30;            // Add in ASCII offset
     // Blank leading zeros
        for(i=4;i>0;i--){                   // Loop through each value
        if(bcd_n[i]==0x30){                 // If the leading values are zero
            bcd_n[i]=0x20;                  // replace with a space
        }
        else{break;}                        // When first non zero value found, exit    
        }            
}    

void display_RPM_act(){
    int i;

    bin2bcd(rpm_act);    
    lcd_ins(LINE2);                     // Point to line 2
    for(i=4;i>0;i--){                   // Write digits
        lcd_chr(bcd_n[i]);              //    
    }
    lcd_chr(bcd_n[0]);
}

void display_RPM_req(){
    int i;
    bin2bcd(rpm);
    lcd_ins(LINE1);                     // Point to line 2
    for(i=4;i>0;i--){                   // Write digits
        lcd_chr(bcd_n[i]);              //    
    }
    lcd_chr(bcd_n[0]);
}

void display_dutyCycle(){
    bin2bcd(input_dutyCycle);           // Convert Duty Cycle to BCD      
    lcd_ins(LINE1+11);                  // Point to line start
    lcd_chr(bcd_n[2]);                  // Hundreds
    lcd_chr(bcd_n[1]);                  // Tens
    lcd_chr(bcd_n[0]);                  // Units    
    lcd_str("%");                       // Percent    
}     

void display_spindle_state(int sstate){ // Display spindle operating state
    lcd_ins(LINE3+6);
    switch (sstate){
        case STOP:
            lcd_str("STOP");
            break;
        case RUN:
            lcd_str("RUN ");
            break;           
        case IDLE:
            lcd_str("IDLE");
            break;                       
    }            
}

void display_current(){                 // Display current
    bin2bcd(spindle_amps);              // Convert Amps to BCD      
    lcd_ins(LINE3+13);                  // Point to line start    
    lcd_chr(bcd_n[1]);                  // Amps units
    lcd_str(".");                       // Decimal point    
    lcd_chr(bcd_n[0]);                  // Amps tenths
}

void display_RPM_init(){                // Initialise Spindle Display
    lcd_ins(LINE1);
    display_RPM_req();
    lcd_str(" RPM");                    // Add label 
    lcd_ins(LINE2);
    display_RPM_act();   
    lcd_str(" RPM");                    // Add label
//    lcd_ins(LINE3);
//    lcd_str("Spindle ");                // Add state label
    lcd_ins(LINE3+16);
    lcd_str("Amps");                    // Add label
    
    display_spindle_state(IDLE);        // Show spindle state
}

// Status Messages
//
void display_MAN(){
    lcd_ins(LINE4);
    lcd_str(" MAN");                    // Add label     
}

void display_AUTO(){
    lcd_ins(LINE4);
    lcd_str("AUTO");                    // Add label     
}

void display_chuck_open(){
    lcd_ins(LINE4+6);
    lcd_str("CHUCK OPEN  ");            // Add label     
}

void display_chuck_closed(){
    lcd_ins(LINE4+6);
    lcd_str("CHUCK CLOSED");            // Add label
    delay_ms(2000);                     // Wait
    lcd_str("            ");            // Message clear
}
