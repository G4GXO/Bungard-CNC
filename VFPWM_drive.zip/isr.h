// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// ISR Header
//
#ifndef ISR_H
#define	ISR_H

// Defines

// Declarations
extern int PWM1_isr_count;      // ISR pass counter for RPM change rate
extern int IC1_isr_count;       // Speed input PWM ISR pass counter

// Prototypes
void __attribute__((__interrupt__, no_auto_psv)) _PWM1Interrupt(void);
void __attribute__((__interrupt__, no_auto_psv)) _IC1Interrupt(void);
void init_PWM1_isr();
void init_IC1_isr();
extern void modulator();

#endif	/* ISR_H */

