// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// PWM Input Capture Functions
//
// Measure input duty cycle to set spindle RPM from Arduino C-Code controller
//
// The edge timing counts of the PWM input are captured by the IC1 module and 
// assigned to t1..t3 starting with the a rising edge. The duty cycle is 
// extracted by computing the PWM on duration and period and then dividing after
// scaling the on period by a suitable value to support integer division.

#include <xc.h>
#include <stdlib.h>                     //
#include "main.h"
#include "speed_ramps.h"
#include "input_capture.h"              // Header file

unsigned int input_dutyCycle;           // Duty cycle of PWM input
unsigned int t1;                        // Capture event values
unsigned int t2;
unsigned int t3;
unsigned int edge_det;                  // Counter used to detect PWM edges
unsigned int capture_new;               // Flag to mark new result
unsigned int ext_rpm;                   // External RPM
unsigned int pwm_up;                    // Increase speed flag
unsigned int pwm_down;                  // Decrease speed flag

// Measure Duty Cycle of Arduino PWM speed drive
void pwm_capture(){  
    if(edge_det){                       // If edges are seen
        edge_det--;                     // Decrement edge detector value
        if(capture_new){                // Is a new result available?
            input_dutyCycle=((long)100*(abs(t2-t1)))/(abs(t3-t1));
            ext_rpm=input_dutyCycle*1000;
            if(rpm<ext_rpm){            // If rpm is less than ext_rpm
                pwm_up=1;               // set the increase speed flag
                pwm_down=0;             // and clear the slow down flag
            }
            else if(rpm>ext_rpm){       // If rpm is less than ext_rpm
                pwm_up=0;               // clear the speed up flag 
                pwm_down=1;             // and set the slow down flag
            }
            capture_new=0;              // Clear flag
            IC1CON1bits.ICM = 3;        // New capture, rising edge
        }
    }
    else{                               // No edges
        input_dutyCycle=0;              // Zero the duty cycle
        // Reset Input Capture
        IC1CON1bits.ICM = 0;            // Capture off, clear buffers        
        IC1CON1bits.ICOV=0;             // Clear overflow flag
        IC1CON1bits.ICBNE = 0;          // Input capture is empty
        IC1CON1bits.ICM = 3;            // Capture mode; every rising edge
        IC1CON2=0x0000;                 // Module on        
    }
}

