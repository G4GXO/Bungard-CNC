// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Button Routines
//
// Scan buttons and if operated set respective flags for the FSM to operate upon.
// During run state, pressing any button stops the CNC
//
#include <xc.h>
#include "main.h"
#include "delays.h"
#include "buttons.h"            // Include file

int button_chuck;               // Chuck button flag
int buttons_new;                // Current button states
int buttons_last;               // Previous button states

// Test button states for change and if pressed set flag for FSM   
void buttons(){
    // Convert current button states to single word
    buttons_new=(BUTTON_PORT & BUTTON_MASK);
    if(buttons_last^buttons_new){       // Look for change
        buttons_last=buttons_new;
        // Change seen, find button and if pressed set flag
        if(!BUTTON_CHUCK){
            button_chuck=1;             // Set flag
        } 
        debounce();
    }
}

// Initialise buttons
void init_buttons(){
    BUTTON_GND=0;                       // Ensure chuck button ground is low
    buttons_last=BUTTON_MASK;           // Initialise button states as high
    button_chuck=0;                     // Clear flags
}
