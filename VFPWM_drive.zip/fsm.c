// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Finite State Machine
//
// A Function Pointer based scheme for menu navigation and parameter change
//
#include "buttons.h"
#include "encoder.h"
#include "control_fcns.h"
#include "input_capture.h"
#include "speed_ramps.h"
#include "fsm.h"

// State, Event and function to call Structure
//
// Defines the structure of the parameters used to call a function

// Rx States and Events
typedef struct {
        states state;           // New state
        events event;           // New event
        int(*func)();           // Pointer to function to call
    }state_matrix;

// Current State and Event Variables
//
// Holds the current state and the returned event. The initialisation values
// are also defined here to determine where the state machine starts from

    int state=ST_INIT;      // 
    int event=EV_INIT;      //

//--------------------------------------------------------------------------
// State Transition Matrix
//
// This array is used to look up what function to call in response to a new
// event and the current state

    // Controls Matrix
    //
    // All states accessible in Rx
   static state_matrix state_trans[]={
    // State            Event           Function       
    {ST_RUN_MAN,        EV_ENC_PRESS,   (*man_stop)},           // Stop spindle    
    {ST_RUN_MAN,        EV_BUT_CHUCK,   (*man_stop)},           // in manual mode

    {ST_RUN_AUTO,       EV_ENC_PRESS,   (*auto_stop)},          // Stop spindle    
    {ST_RUN_AUTO,       EV_BUT_CHUCK,   (*auto_stop)},          // in auto mode
  
    {ST_RUN_MAN,        EV_ENC_UP,      (*man_rpm_inc)},        // Increase spindle speed
    {ST_RUN_MAN,        EV_ENC_DOWN,    (*man_rpm_dec)},        // Decrease spindle speed

    {ST_RUN_MAN,        EV_RPM_UP,      (*spin_up)},            // Increase run spindle speed
    {ST_RUN_MAN,        EV_RPM_DOWN,    (*spin_down)},          // Decrease run spindle speed    

    {ST_IDLE_MAN,       EV_ENC_UP,      (*man_rpm_inc)},        // Increase idle spindle speed
    {ST_IDLE_MAN,       EV_ENC_DOWN,    (*man_rpm_dec)},        // Decrease idle spindle speed    
    {ST_IDLE_MAN,       EV_ENC_PRESS_REL,   (*man_start)},          // Start Spindle

    {ST_RUN_AUTO,       EV_PWM_UP,      (*auto_rpm_inc)},       // Increase spindle speed
    {ST_RUN_AUTO,       EV_PWM_DOWN,    (*auto_rpm_dec)},       // Decrease spindle speed
       
    {ST_RUN_AUTO,       EV_RPM_UP,      (*spin_up)},            // Increase run spindle speed
    {ST_RUN_AUTO,       EV_RPM_DOWN,    (*spin_down)},          // Decrease run spindle speed
    
    {ST_IDLE_AUTO,      EV_ENC_PRESS_REL,   (*auto_start)},         // Start Spindle

    // Chuck Open/Close
    {ST_IDLE_MAN,       EV_BUT_CHUCK,   (*chuck_open_man)},     // Open chuck in man mode
    {ST_IDLE_AUTO,      EV_BUT_CHUCK,   (*chuck_open_auto)},    // Open chuck in auto mode
    
    {ST_CHUCK_MAN,      EV_BUT_CHUCK,   (*chuck_close_man)},    // Close chuck in man mode
    {ST_CHUCK_AUTO,     EV_BUT_CHUCK,   (*chuck_close_auto)},   // Close chuck in auto mode   

    // Mode Change
    {ST_IDLE_MAN,       EV_ENC_HOLD,    (*auto_mode)},          // Switch spindle to auto mode    
    {ST_IDLE_AUTO,      EV_ENC_HOLD,    (*man_mode)},           // Switch spindle to manual mode     

    // Initialisation
    {ST_INIT,           EV_NONE,        (*init_fsm)},           // Initialisation
    };

// Runtime calculation of state table entries (saves manual coding)
#define STATE_COUNT sizeof(state_trans)/sizeof(state_trans[0])

//--------------------------------------------------------------------------
// Control Event Routine
//
// Examines the button, encoder and PTT states. If a change is seen the corresponding
// event state is passed to the finite state machine for action. The order in which
// the events are handled is important.

int get_control_event(){
    //
    // Encoder Events
    //
    if(enc_up){                     // Check encoder up flag    
        enc_up=0;                   // Clear flag
        return EV_ENC_UP;           // Return event
    }
    else if(enc_down){              // Check encoder down flag    
        enc_down=0;                 // Clear flag
        return EV_ENC_DOWN;         // Return event
    }
    else if(enc_press){             // Check encoder press flag
        enc_press=0;                // Clear press flag    
        return EV_ENC_PRESS;        // Return event
    }
    else if(enc_press_rel){         // Check encoder press release flag
        enc_press=0;                // Clear press flag    
        enc_press_rel=0;            // Clear flag
        return EV_ENC_PRESS_REL;    // Return event
    }
    else if(enc_hold){              // Check encoder press flag
        enc_hold=0;                 // Clear flag
        return EV_ENC_HOLD;         // Return event
    }
    //
    // PWM Speed Control Events (Auto Mode)
    //
    if(pwm_up){                     // PWM RPM increase
        pwm_up=0;                   // Clear flag
        return EV_PWM_UP;           // Return event
    }
    else if(pwm_down){              // PWM RPM decrease    
        pwm_down=0;                 // Clear flag
        return EV_PWM_DOWN;         // Return event        
    }
    //
    // Button Events
    //
    else if(button_chuck){          // Check chuck button flag
        button_chuck=0;             // Set, clear flags
        return EV_BUT_CHUCK;        // Return event
    }    
    //
    // Spindle Events
    //
    else if(rpm_up){                     
        rpm_up=0;                   // Clear flag
        return EV_RPM_UP;           // Return event
    }
    else if(rpm_down){              // Check slow down flag
        rpm_down=0;                 // Clear flag
        return EV_RPM_DOWN;         // Return event        
    }
    //
    //-------------------------------------------------------------------------- 
    // The fall-through event (nothing)
    return EV_NONE;
}
//------------------------------------------------------------------------------
// Controls Finite State Machine
//
// This short routine checks for a new event and if seen uses the State Transition
// Matrix to determine the current state and corresponding action for the new event.
//

int event_last;                     // Previous event
int state_last;                     // Previous state

void fsm(){

    int i;                          // Counter

    event = get_control_event();    // Check for new event
//    if((event!=event_last)||state!=state_last){
//        event_last=event;           // Update previous event
//        state_last=state;           // Update previous state
        
    // Step through each state and check for correlation with state and event
    // In addition to individual states and events an "ANY" condition is
    // included to apply an action irrespective of state or event.
    for(i=0; i<STATE_COUNT; i++){
        if((state_trans[i].state == state)||(state_trans[i].state == ST_ANY)){
            if((state_trans[i].event == event)||(state_trans[i].event==EV_ANY)){
                 // Call the function associated with transition (also returns next state)
                state = (state_trans[i].func)();
                break;
             }
         }
    }
//}
}
