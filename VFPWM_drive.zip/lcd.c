// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// HD44780 Display Driver

// Include files
#include <xc.h>
#include "main.h"
#include "analogues.h"
#include "delays.h"
#include "lcd.h"

unsigned char lcd_data;					// Data to and from the LCD
unsigned int lcd_mode;					// 1 = character, 0 = instruction
unsigned int lcd_bf;					// Busy flag nibble	

const int LCD_INIT_STRING[5]={0x0028, 0x0008, 0x0001, 0x0006, 0x000c};
                             	// These bytes configure the LCD

// Busy Check routine
// Test data bit 7 to see if the LCD is available
void lcd_busy_check(){					
 	  TRISB=(PORTB_DIR|LCD_READ);   // Set port to read without interfering with the LED  
  do{            
	  LCD_RS=0;
      LCD_RW = 1;
      pause();
      LCD_E = 1;
      pause();
      lcd_bf = PORTB;		       	// Upper nibble held in lower 4 bits of "nibble"
      pause();
      LCD_E = 0;
      pause();
      LCD_E = 1;
      pause();          			// Second "dummy" read to complete 4 bit cycle
      LCD_E = 0;                    
	  pause();	
	}while (lcd_bf&LCD_BF);         // Check busy flag bit
	TRISB=(PORTB_DIR&LCD_WRITE);    // Restore write direction 
}

// Write an 8 bit character or instruction code to the LCD in 4 bit mode
int	 lcd_write(unsigned int lcd_data){
	lcd_busy_check();
    if(lcd_mode){
        LCD_RS=1;
    }
    else{
        LCD_RS=0;
    }
	LCD_RW=0;
	pause();
    LCD_E = 1;
	pause();
	LATB=(LATB&LCD_CLR);					// Clear LCD data port
	LATB=(LATB|((lcd_data<<1)&LCD_MASK));	// Isolate upper nibble, align data and place on port		
 	pause();
    LCD_E = 0;                      	   	// Data latched on falling edge
	pause();
    LCD_E = 1;
	pause();
	LATB=(LATB&LCD_CLR);					// Clear LCD data port
	LATB=(LATB|((lcd_data<<5)&LCD_MASK));	// Isolate lower nibble, align data and place on port
 	pause();
    LCD_E = 0;                        		// Data latched on falling edge 
	return(0);
}

// Write a character to the LCD
void lcd_chr(unsigned char lcd_data){
	lcd_mode=1;	
	lcd_write(lcd_data);
}

// Write an instruction to the LCD
void lcd_ins(unsigned char lcd_data){
	lcd_mode=0;
	lcd_write(lcd_data);
    pause();
}

// Write a character string to the LCD
void lcd_str(register const char *str){
   while((*str)!=0){
      lcd_chr(*str);
      str++;}
}

// Initialise the LCD in 4 bit mode with busy flag
void init_lcd(){
 	int i;
    TRISB=(PORTB_DIR&LCD_WRITE);
    LATB = (LATB&LCD_CLR);                  // Clear LCD data port    
	delay_ms(100);                         	// Start up delay
    LCD_RS = 0;
    LCD_RW = 0;
    LCD_E = 0;
     for(i=0;i<3;++i){						// Write initialisation codes
        LCD_E = 1;                    		// Raise enable
        pause();                    	  
        // Send 0x30 to LCD port
        LATB = (LATB|0x0060);               // Put "3" on upper 4 bits of lcd byte
        delay_ms(30);
        LCD_E = 0;
        pause();
        LATB = (LATB&LCD_CLR);              // Clear LCD data port
        }
   	LCD_E = 1;
	pause();
    // Send 0x20 to LCD port
   	LATB = (LATB|0x0040);                	// Put 2 on upper 4 bits of lcd byte
   	delay_ms(30);
   	LCD_E = 0;                    			// Busy flag now active
	lcd_busy_check();						// Wait for busy flag to clear
    for(i=0;i<5;++i){						// Write configuration string
     	lcd_ins(LCD_INIT_STRING[i]);		
   		}
	lcd_ins(LINE1);							// Start up message
	lcd_str("VF Drive v1.0");
    lcd_ins(LINE2);
	lcd_str("(c)Ron Taylor");
   
	delay_ms(2000);

	lcd_ins(CLEAR);                         // LCD initialisation complete    
}	
	


