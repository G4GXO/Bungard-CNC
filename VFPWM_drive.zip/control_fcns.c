// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Control Functions
//
#include <xc.h>
#include "main.h"
#include "fsm.h"
#include "delays.h"
#include "display.h"
#include "pwm.h"
#include "analogues.h"
#include "speed_ramps.h"
#include "input_capture.h"
#include "chuck.h"
#include "encoder.h"
#include "buttons.h"
#include "control_fcns.h"

//-------------------------------------------------------------------------------
//
// Spindle Operating Mode
//
// Manually select between manual and auto modes
//
//-------------------------------------------------------------------------------
//
// Switch from manual to auto
int auto_mode(){
    display_AUTO();                         // Show new mode
    return ST_IDLE_AUTO;                    // Return state
}

// Switch from manual to auto
int man_mode(){
    display_MAN();                          // Show new mode
    return ST_IDLE_MAN;                     // Return state
}

//-------------------------------------------------------------------------------
//
// Spindle Start/Stop
//
// The drive pin enable/disable controls whether the PWM module drives the output
// pins or whether they are set by the P1VDCON register states. This allows the
// outputs to be effectively isolated from the PWM module whilst keeping the 
// the interrupts running. The pin states may also be used for braking current.
//
//-------------------------------------------------------------------------------
//
// Manual Mode
int man_stop(){
    drive_phase_inc=0;                      // Set phase increment to zero
    drive_scale=0;                          // Set amplitude to zero
    pwm_out_dis();                          // Set drive pins low
    rpm_act=0;                              // Zero RPM
    display_spindle_state(STOP);            // Show state
    delay_ms(2000);                         // Delay
    display_spindle_state(IDLE);            // Switch state
    enc_rel_inhibit();                      // Inhibit an encoder release event
                                            // to prevent a spindle re-start    
    return ST_IDLE_MAN;                     // Return state
}

int man_start(){
    pwm_out_en();                           // Enable drive pins
    I_scale=ISCALE;                         // Reset current scaling
    ADC_amps_new=0;                         // Clear ADC flag
    rpm_act=RPMstart;                       // Start condition for spindle ramp 
    display_spindle_state(RUN);             // Show state
    return ST_RUN_MAN;                      // Return state
}

int man_idle(){
    display_spindle_state(IDLE);            // Show state
    return ST_IDLE_MAN;                     // Return state
}
//------------------------------------------------------------------------------
// Auto Mode
int auto_stop(){
    drive_phase_inc=0;                      // Set phase increment to zero
    drive_scale=0;                          // Set amplitude to zero
    pwm_out_dis();                          // Set drive pins low
    rpm_act=0;                              // Zero RPM
    display_spindle_state(STOP);            // Show state
    delay_ms(2000);                         // Delay
    display_spindle_state(IDLE);            // Switch state
    enc_rel_inhibit();                      // Inhibit an encoder release event
                                            // to prevent a spindle re-start
    return ST_IDLE_AUTO;                    // Return state
}

int auto_start(){
    pwm_out_en();                           // Enable drive pins
    I_scale=ISCALE;                         // Reset current scaling
    ADC_amps_new=0;                         // Clear ADC flag
    rpm_act=RPMstart;                       // Start condition for spindle ramp 
    display_spindle_state(RUN);             // Show state
    return ST_RUN_AUTO;                     // Return state 
}

int auto_idle(){
    display_spindle_state(IDLE);            // Show state
    return ST_IDLE_AUTO;                    // Return state
}
//-------------------------------------------------------------------------------
//
// Spindle Drive Manual Frequency Set
//
// Increment or decrement RPM by encoder turn. As these functions operate in
// idle and run states, the state is captured on entry and returned on exit.
//-------------------------------------------------------------------------------
int man_rpm_inc(){                          // Increase spindle speed
    int temp;                               // Temporary store
    temp=state;                             // Get entry state    
    rpm=rpm+500;                            // Increment RPM
    if(rpm>RPMmax){                         // If limit exceeded
        rpm=RPMmax;                         // hold at limit
    }
    return temp;                            // Return entry state
}

int man_rpm_dec(){                          // Decrease spindle speed
    int temp;                               // Temporary store
    temp=state;                             // Get entry state        
    rpm=rpm-500;                            // Decrement RPM
    if(rpm<RPMmin){                         // If limit exceeded
        rpm=RPMmin;                         // hold at limit
    }
    return temp;                            // Return entry state
}
//-------------------------------------------------------------------------------
//
// Spindle Drive Auto Frequency Set
//
// Increment or decrement RPM by spindle PWM speed control input. As these 
// functions operate in idle and run states, the state is captured on entry 
// and returned on exit.
//-------------------------------------------------------------------------------
int auto_rpm_inc(){
    int temp;                               // Temporary store
    temp=state;                             // Get entry state    
    rpm=ext_rpm;                            // Copy ext RPM to RPM
    if(rpm>RPMmax){                         // If max speed exceeded
        rpm=RPMmax;                         // hold at RPMmax 
    }
    return temp;                            // Return entry state   
}

int auto_rpm_dec(){
    int temp;                               // Temporary store
    temp=state;                             // Get entry state    
    rpm=ext_rpm;                            // Copy ext RPM to RPM
    if(rpm<RPMmin){                         // If les than RPMmin
        rpm=RPMmin;                         // hold at RPMmin
    }
    return temp;                            // Return entry state    
}

//-------------------------------------------------------------------------------
//
// Spindle Drive Frequency Change
//
// This function adjusts the spindle drive frequency in 1Hz steps to match the 
// requested RPM value. As the phase increment changes new values of the V/f 
// drive are also calculated as a linear transfer function based upon spindle 
// RPM, gradient and start drive level. The gradient and start drive level are 
// pre-calculated in the header file and use a simple y=mx+c function.
//
// The drive phase right shift takes out the multiply by 16384 in the phase
// factor, used to increase resolution at low frequencies.
//
// These functions are made common to manual and auto modes by capturing the
// entry state and returning it at function exit.
//-------------------------------------------------------------------------------

int spin_up(){
    int temp;                                               // Temp entry state store
    temp=state;                                             // Get entry state
    rpm_act++;                                              // Increase RPM
    freq=rpm_act/60;                                        // Calculate drive frequency
    drive_phase_inc=((unsigned long)freq*phase_factor)>>14; // Calculate phase increment
    drive_scale=c+(((unsigned long)rpm_act*m)>>15);         // Calculate drive voltage scaling factor, y=mx+c
    return temp;                                            // Return entry state
}

int spin_down(){
    int temp;                                               // Temp entry state store
    temp=state;                                             // Get entry state    
    rpm_act--;                                              // Decrease RPM
    freq=rpm_act/60;                                        // Calculate drive frequency   
    drive_phase_inc=((unsigned long)freq*phase_factor)>>14; // Calculate phase increment
    drive_scale=c+(((unsigned long)rpm_act*m)>>15);         // Calculate drive voltage scaling factor, y=mx+c
    return temp;                                            // Return entry state  
}
//-------------------------------------------------------------------------------
// Chuck Functions
//
// Toggle chuck open/close from manual and automatic spindle speed modes.
//
int chuck_open_man(){                                       // Open chuck in manual mode
    CHUCK=1;                                                // Open chuck
    display_chuck_open();                                   // Display state
    return ST_CHUCK_MAN;                                    // Return state
}

int chuck_close_man(){                                      // Close chuck in manual mode
    CHUCK=0;                                                // Open chuck
    display_chuck_closed();                                 // Display state     
    return ST_IDLE_MAN;                                     // Return state
}
//
// Automatic mode
//
int chuck_open_auto(){                                      // Open chuck in automatic mode
    CHUCK=1;                                                // Open chuck
    display_chuck_open();                                   // Display state
    return ST_CHUCK_AUTO;                                   // Return state
}

int chuck_close_auto(){                                     // Close chuck in automatic mode
    CHUCK=0;                                                // Open chuck
    display_chuck_closed();                                 // Display state     
    return ST_IDLE_AUTO;                                    // Return state
}
//
//-------------------------------------------------------------------------------
// Test Functions
/*
int encoder_up(){
    int temp=state;
    lcd_ins(CLEAR);                         // Clear LCD
    lcd_ins(LINE2+6);                       // Point to second line
    lcd_str("UP");                          // Message
    return temp;
}

int encoder_down(){
    int temp=state;
    lcd_ins(CLEAR);                         // Clear LCD
    lcd_ins(LINE2+6);                       // Point to second line
    lcd_str("DOWN");                        // Message
    return temp;
}

int encoder_press(){
    int temp=state;
    lcd_ins(CLEAR);                         // Clear LCD
    lcd_ins(LINE2+6);                       // Point to second line
    lcd_str("PRESS");                       // Message
    return temp;
}

int encoder_hold(){
    int temp=state;
    lcd_ins(CLEAR);                         // Clear LCD
    lcd_ins(LINE2+6);                       // Point to second line
    lcd_str("HOLD");                        // Message
    return temp;
}
*/
//-------------------------------------------------------------------------------
// FSM Initialisation
int init_fsm(){
    drive_phase_inc=0;                      // Set phase increment to zero
    drive_scale=0;                          // Set amplitude to zero
    pwm_out_dis();                          // Set drive pins low
    rpm_act=0;                              // Zero RPM    
    display_MAN();                          // Start in manual mode
return ST_IDLE_MAN;                         // Return state
}

