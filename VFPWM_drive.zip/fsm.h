// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// FSM Header
//
#ifndef FSM_H
#define	FSM_H

// State and Event Enumerations
//
// The enum type assigns incrementing numerical values to each item defined starting
// at zero unless otherwise specified.

    typedef enum {          // State List
        ST_INIT,            // 0 Initialisation (state is initialised to 0 by compiler)
        ST_STOP,            // Stop spindle
        ST_START,           // Start spindle
        ST_RUN_MAN,         // Spindle running under manual control
        ST_RUN_AUTO,        // Spindle running under automatic control                
        ST_IDLE_MAN,        // Spindle not running        
        ST_IDLE_AUTO,       // Spindle not running
        ST_CHUCK_MAN,       // Chuck operation in manual mode
        ST_CHUCK_AUTO,      // Chuck operation in automatic mode                
        ST_ANY,             // Any state
    }states;

    typedef enum {          // Event List
        EV_ANY,             // Any event
        EV_OVER_CURRENT,    // Over current detected
        EV_STOP,            // Spindle stop
        EV_ENC_UP,          // Encoder up
        EV_ENC_DOWN,        // Encoder down
        EV_ENC_PRESS,       // Encoder press 
        EV_ENC_PRESS_REL,   // Encoder press and release
        EV_ENC_HOLD,        // Encoder hold
        EV_PWM_UP,          // PWM input speed up
        EV_PWM_DOWN,        // PWM input slow down   
        EV_BUT_CHUCK,       // Chuck button press      
        EV_RPM_UP,          // Increase RPM
        EV_RPM_DOWN,        // Decrease RPM                
        EV_START,           // Spindle start
        EV_NONE,            // No event        
        EV_INIT,            // Initialisation
    }events;
    
// Declarations
extern int state;
extern int event_last;                     // Previous event
extern int state_last;                     // Previous state

// Prototypes
int get_control_event();
void fsm();

#endif	/* FSM_H */

