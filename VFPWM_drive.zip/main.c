// Variable Frequency PWM Driver for Kavo High Frequency Spindle
//
// (c)Ron Taylor G4GXO
//
// This code is provided for non commercial use only and may be distributed, copied
// and modified providing that this header is left in place without change.
//
// Version
//
// 1.0 
//
// Things to do
//
// 1. 
// 
//==============================================================================
#include <xc.h>
#include "main.h"
// Prepare processor 
//        
// Processor Configuration for FRC start up and automatic switch to the external oscillator and PLL (IESO bit)
// FICD

#pragma config ICS = PGD3               // ICD Communication Channel Select bits (Communicate on PGEC1 and PGED1)
#pragma config JTAGEN = OFF             // JTAG Enable bit (JTAG is disabled)

// FPOR
#pragma config BOREN = ON               // BOR is enabled
#pragma config ALTI2C1 = OFF            // Alternate I2C1 pins (I2C1 mapped to SDA1/SCL1 pins)
#pragma config ALTI2C2 = OFF            // Alternate I2C2 pins (I2C2 mapped to SDA2/SCL2 pins)
#pragma config WDTWIN = WIN25           // Watchdog Window Select bits (WDT Window is 25% of WDT period)

// FWDT
#pragma config WDTPOST = PS32768        // Watchdog Timer Postscaler bits (1:32,768)
#pragma config WDTPRE = PR128           // Watchdog Timer Prescaler bit (1:128)
#pragma config PLLKEN = ON              // PLL Lock Enable bit (Clock switch to PLL source will wait until the PLL lock signal is valid.)
#pragma config WINDIS = OFF             // Watchdog Timer Window Enable bit (Watchdog Timer in Non-Window mode)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable bit (Watchdog timer enabled/disabled by user software)

// FOSC
#pragma config POSCMD = NONE            // Primary Oscillator Mode Select bits (Primary Oscillator disabled)
#pragma config OSCIOFNC = ON            // OSC2 Pin Function bit (OSC2 is clock output)
#pragma config IOL1WAY = ON             // Peripheral pin select configuration (Allow only one reconfiguration)
#pragma config FCKSM = CSECMD           // Clock Switching Mode bits (Clock switching is enabled,Fail-safe Clock Monitor is disabled)

// FOSCSEL
#pragma config FNOSC = FRC              // Oscillator Source Selection (Internal Fast RC (FRC))
#pragma config PWMLOCK = OFF            // PWM Lock Enable bit (Certain PWM registers may only be written after key sequence)
#pragma config IESO = OFF               // Two-speed Oscillator Start-up Enable bit (Start up with user-selected oscillator source)

// FGS
#pragma config GWRP = OFF               // General Segment Write-Protect bit (General Segment may be written)
#pragma config GCP = OFF                // General Segment Code-Protect bit (General Segment Code protect is Disabled)

// Debug Config
/*
#pragma config ICS = PGD1 // ICD Communication Channel Select bits (Communicate on PGEC3 and PGED3)
#pragma config FWDTEN = OFF // Watchdog Timer Enable bit (Watchdog timer enabled/disabled by user software)
#pragma config OSCIOFNC = OFF // OSC2 Pin Function bit (OSC2 is clock output)
#pragma config FCKSM = CSECMD // Clock Switching Mode bits (Clock switching is enabled,Fail-safe Clock Monitor is disabled)
*/
// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

// Specify Project Include Files

#include <stdio.h>                      // Standard Includes for I/O etc., probably not needed 
#include <stdlib.h>                     //

extern  void flash_operations(void);    // EEPROM emulation routines
extern  void modulator(void);           // PWM Modulator
extern  void asm_def(void);             // Assembler definitions

// Program includes
#include "main.h"                       // Main header file
#include "delays.h"                     // Delay functions
#include "lcd.h"                        // LCD functions
#include "analogues.h"                  // Analogue functions
#include "pwm.h"                        // PWM functions
#include "speed_ramps.h"                // Speed change control
#include "input_capture.h"              // External PWM speed control input
#include "display.h"                    // Data display
#include "buttons.h"                    // Buttons    
#include "encoder.h"                    // Encoder inputs
#include "eeprom.h"                     // EEPROM emulation functions
#include "fsm.h"                        // Finite State Machine
#include "isr.h"                        // ISR
#include "pps_mapping.h"                // Peripheral pin mapping

// Start of Main program
//
int main(void){
// Configure PLL prescaler, PLL postscaler, PLL divisor for 70MIPS operation with 7.37MHz FRC
// For 70MIPS system clock =70*2=140MHz, PLL=140*2=280MHz, Use 7.37MHz/2=3.68MHz PLL Input, M=280/3.68=74
    PLLFBD=74;                  // M = 76,	280MHz VCO divided by 76 = 3.68Hz
	CLKDIVbits.PLLPOST = 0;		// N2 = 2,	280MHz/2 = 140MHz
	CLKDIVbits.PLLPRE = 0; 		// N1 = 2, Fin = 3.68MHz

// Clock switching
	__builtin_write_OSCCONH(0x01);          // Initiate Clock Switch to FRC with PLL (NOSC = 0b001)
	__builtin_write_OSCCONL(OSCCON|0x01);   //
	while(OSCCONbits.COSC!= 0b001){};       // Wait for Clock switch to occur
	while(OSCCONbits.LOCK!= 1){};           // Wait for PLL to lock
        asm("nop");
        asm("nop");
        asm("nop");
        asm("nop");    

    // Configure Ports
    ANSELA=0;
    ANSELB=0;                       // All ports digital for now
    ANSELC=0;

    AD1CON1=0;
    AD1CON2=0;

//        PMCON=0;        
        
	// Configure I/O Port Directions
    TRISA=PORTA_DIR;                // Set up PORTA directions
	TRISB=PORTB_DIR;                // Set up PORTB directions
    TRISC=PORTC_DIR;                // Set up PORTC directions

    // Configure Open Drain pins for +5V interface
//    ODCA=PORTA_OD;                  // Configure PORTA open drains
//    ODCB=PORTB_OD;                  // Configure PORTB open drains
//    ODCC=PORTC_OD;                  // Configure PORTC open drains
    
    // Configure weak pull ups for encoder inputs and set all unused pins as outputs
    // (Hard pull ups using external resistors in use))
    CNPUA=WEAK_PUA;
    CNPUB=WEAK_PUB;
    CNPUC=WEAK_PUC;
    
    // Disable unused peripheral modules to reduce power and free up I/O pins (see data sheet)
    PMD1=PMD1DIS;
    PMD2=PMD2DIS;
    PMD3=PMD3DIS;
    PMD4=PMD4DIS;
    PMD6=PMD6DIS;
    PMD7=PMD7DIS;
    
    // Pin Mapping
    pin_mapper();                   // Assign peripherals to pins                  
    
    // Initialisation Routines
    init_encoder();                 // Initialise encoder
    init_buttons();                 // Initialise buttons
    init_adc();                     // Initialise ADC
    init_pwm();                     // Initialise PWM before sin table for scaling factor    
    init_sin_table();               // Load sine coefficients    
    init_rpm();                     // Initialise factors for ramp calculations
    init_PWM1_isr();                // Initialise PWM drive ISR
    init_IC1_isr();                 // Initialise speed control ISR
    init_lcd();                     // Initialise LCD      
    fsm();                          // Run FSM for initialisation
    display_RPM_init();             // Place labels on LCD
    PTCONbits.PTEN=1;               // Start PWM
    INTCON2bits.GIE=1;              // Interrupts running
    
	// Main Program Loop (Endless)

    do{
        Idle();                     // Wait here and shut down to save power until next interrupt
        pwm_capture();              // Capture PWM input speed duty cycle
        run_ADC();                  // Run ADC functions
        encoder();                  // Check encoder states
        buttons();                  // Check button states
        rpm_chk();                  // Check for RPM mismatch
        fsm();                      // Run FSM
        // Reduce display rate to prevent slowing main loop too much
        if(!PWM1_isr_count){        // Check ISR count state, if zero
            display_dutyCycle();    // Show input PWM duty cycle
            display_RPM_req();      // update the requested and actual    
            display_RPM_act();      // RPM displays.
            display_current();      // Show spindle current
            PWM1_isr_count=2000;    // Reload down counter.
        }
    }while(1);    
return 0;
}
  
