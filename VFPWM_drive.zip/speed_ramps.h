// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Acceleration and Deceleration Ramps Header File
//
#ifndef SPEED_RAMPS_H
#define SPEED_RAMPS_H

// Defines
#define fs          20000           // PWM period frequency
#define ISR_100uSEC (100000UL)/fs   // ISR passes in 100usec
#define ISR_200uSEC 5 //(200000UL)/fs   // ISR passes in 200usec
#define ISR_1mSEC   (1000000UL)/fs  // ISR passes in 1msec
#define ISR_10mSEC  10*ISR_1mSEC    // ISR passes in 10msec
#define ISR_100mSEC 100*ISR_1mSEC   // ISR passes in 100msec
#define RPMmax      60000UL         // Max RPM
#define RPMmin      5000UL          // Min RPM
#define RPMstart    RPMmin          // Start RPM
#define FMAX        RPMmax/60       // Max drive frequency
#define FMIN        RPMmin/60       // Min drive frequency
#define RPM_UPDATE  3               // ISR passes per RPM step change              
#define VSTART  8192                // Start scaling value for V/f calculations
#define VMAX    32767               // End scaling value for V/f calculations

// Compute gradient of linear V/f transform as an integer equation of the form y=mx+c
//
// m is computed from the RPM range and the start drive value. This assumes a maximum
// drive of 0x7fff. With m calculated, c is derived from y-mx at 60000 RPM. See AN984
// for a brief introduction to induction motor V/f curves.
/*
//#define m   ((32768UL*(32767-VSTART))/(RPMmax-RPMmin))
//#define c   (32767-((RPMmax*m)/32768))
#define m   ((32768UL*(VMAX-VSTART))/(RPMmax-RPMmin))
#define c   (16383-((RPMmax*m)/32768))
*/

// Declarations
extern unsigned int freq;                          // Spindle drive frequency
extern unsigned int rpm;                           // Requested Spindle RPM
extern unsigned int rpm_act;                       // Actual Spindle RPM   
extern unsigned long phase_factor;                 // Used to speed up phase increment calculation
extern unsigned int rpm_up;                        // RPM increase flag
extern unsigned int rpm_down;                      // RPM decrease flag    
extern int rpm_update;                             // Number of ISR passes per RPM increment/decrement
extern unsigned int m;                             // V/f gradient
extern unsigned int c;                             // V/f constant

// Prototypes
void rpm_chk();
void init_rpm();

#endif /* SPEED_RAMPS_H */