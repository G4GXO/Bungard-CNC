// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Chuck Control Routines
//
#include <xc.h>
#include "main.h"
#include "chuck.h"

void init_chuck(){
    CHUCK_GND=0;            // Ensure ground reference is in place
}