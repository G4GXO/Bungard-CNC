// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Chuck Header
//

#ifndef CHUCK_H
#define	CHUCK_H

// Chuck Control Output
#define CHUCK       _LATA0      // Chuck compressed air valve control
#define CHUCK_GND   _LATA1      // Ground for chuck control


// Prototypes
void init_chuck();

#endif	/* CHUCK_H */

