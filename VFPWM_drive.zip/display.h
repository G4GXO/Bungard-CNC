// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Display Header File
//
#ifndef DISPLAY_H
#define DISPLAY_H

// Spindle State Enumerations 
    typedef enum {       // Spindle State List
        // Operating menu states
        STOP,            // Stop spindle
        START,           // Start spindle
        RUN,             // Spindle running
        IDLE,            // Spindle not running        
    }spindle_states;

// Declarations
extern unsigned int bin_n;          // Binary integer input
extern unsigned char bcd_n[5];		// 5 digit BCD output    
    
// Prototypes
void bin2bcd(int); 
void display_RPM_act();
void display_RPM_req();
void display_dutyCycle();
void display_spindle_state(int);
void display_current();
void display_RPM_init();
void display_MAN();
void display_AUTO();
void display_chuck_open();
void display_chuck_closed();
    
#endif
