// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
#include <xc.h>
#include "main.h"
#include "pwm.h"
#include "input_capture.h"
#include "isr.h"

// Interrupt Service Routines
int PWM1_isr_count=0;                           // ISR pass counter for RPM change rate
int IC1_isr_count=0;                            // Speed input PWM ISR pass counter

void __attribute__((__interrupt__, no_auto_psv)) _PWM1Interrupt(void){
    if(PWM1_isr_count){PWM1_isr_count--;}       // ISR counter for time delay use by control functions
    modulator();                                // Run Modulator
    IFS5bits.PWM1IF=0;                          // Clear interrupt flag  
}

void __attribute__((__interrupt__, no_auto_psv)) _IC1Interrupt(void){
    IFS0bits.IC1IF = 0;                         // Clear interrupt flag   
//    IC1CON1bits.ICBNE=0;
//    IC1CON1bits.ICOV=0;   
    edge_det=EDGE_ACTIVE;                       // Reset edge detect counter
    IC1_isr_count++;                            // Increment pass counter
    switch(IC1_isr_count){
        case 1:                                 // 1st interrupt, capture rising edge count       
            IC1CON1bits.ICM=2;                  // Switch to falling edge detection
            break;
        case 2:                                 // 2nd interrupt, capture falling edge count        
            IC1CON1bits.ICM=3;                  // Switch to rising edge detection
            break;            
        case 3:                                 // 3rd interrupt, capture rising edge count
            t1=IC1BUF;                          // Transfer buffer counts to variables           
            t2=IC1BUF;                          //
            t3=IC1BUF;                          //
            capture_new=1;                      // Signal new result available
            IC1CON1bits.ICM=0;                  // Switch off detection and clear buffer                 
            IC1_isr_count=0;                    // Reset pass counter
            IC1CON1bits.ICBNE=0;
            IC1CON1bits.ICOV=0;               
            break;
    }
}



// PWM1 Interrupt Initialisation Routine
// Use Trigger as interrupt source
void init_PWM1_isr(){
    INTCON1bits.NSTDIS=1;                       // No nesting
    IPC23bits.PWM1IP=7;                         // Highest priority
    
    TRIG1=0;                                    // Trigger on PWM1 cycle start
    TRGCON1=0x0000;                             // Trigger on every cycle
    PWMCON1bits.TRGIEN=1;                       // Enable Trigger as PWM1 interrupt source
    
    IFS5bits.PWM1IF=0;                          // Clear interrupt flag
    IEC5bits.PWM1IE=1;                          // Enable interrupt
}

// IC1 Interrupt Initialisation Routine
// Used to measure PWM speed control input duty cycle
void init_IC1_isr(){
    IPC0bits.IC1IP = 6;                         // Set module interrupt priority as 6    
    IC1CON1bits.ICSIDL = 0;                     // Input capture will continue to operate in CPU idle mode
    IC1CON1bits.ICTSEL = 7;                     // Peripheral (FP) is the clock source for the IC1 module
    IC1CON1bits.ICI = 0;                        // Interrupt on every capture event
    IC1CON1bits.ICBNE = 0;                      // Input capture is empty
    IC1CON1bits.ICOV=0;    
    IC1CON1bits.ICM = 3;                        // Capture mode; every rising edge
    IC1CON2=0x0000;                             //    
    IFS0bits.IC1IF = 0;                         // Clear the IC1 interrupt status flag
    IEC0bits.IC1IE = 1;                         // Enable IC1 interrupts  
}
