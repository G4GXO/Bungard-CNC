// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Analogues Header File
#ifndef ANALOGUES_H
#define ANALOGUES_H

#define ADC_COUNT       100     // Number of ISR passes for ADC update cycle
#define ADC_COUNT_1     50      // Number of ISR passes between 1st ADC update
#define ADC_COUNT_2     0       // Number of ISR passes between 2st ADC update

#define I_ALPHA         0x7000          // Exponential Moving Average weighting factor    
#define I_ALPHA_1       0x7fff-I_ALPHA  // 1-I_alpha
// Scaling factor to convert ADC input voltage to current in 100's of mA
// This factor accounts for the sensing resistor value, the buffer amplifier 
// gain, ADC range of 0..3v3 and the ADC resolution of 1024 steps. By dividing
// the result by 32768 (which is achieved by a right shift) the ADC result is 
// converted to an integer representing 100's of mA. The DP is inserted by the 
// display function to display Amps to one decimal place.
#define AMPS_SCALE      3376    // Factor*32768 to convert ADC result to 100s mA
                                // Shift right by 15 to remove factor after
                                // scaling ADC result
// Declarations
extern int ADC_update;                       // Analogue update counter (ISR counter)
extern int spindle_speed;                    // Spindle speed control input
extern unsigned int I_new;                   // Spindle amps new
extern unsigned int I_last;                  // Spindle current previous
extern unsigned int I_alpha;                 // Exponential Moving Average weighting factor
extern unsigned int I_alpha_1;               // 1-alpha
extern unsigned int I_avg;                   // Averaged current
extern unsigned int spindle_amps;            // Binary amps scaled by 10 as integer 100s mA
extern int ADC_amps_new;                     // Flag to signal new measurement available

// Prototypes               
void run_ADC();
void init_adc();

#endif