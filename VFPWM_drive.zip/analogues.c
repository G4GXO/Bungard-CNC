// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Analogue Functions
#include <xc.h>
#include "main.h"
#include "analogues.h"          // Header file

int ADC_update=ADC_COUNT;                       // Analogue update counter (ISR counter)
//int spindle_speed;                              // Spindle speed control input
unsigned int I_new;                             // Spindle amps new
unsigned int I_last;                            // Spindle current previous
unsigned int I_alpha;                           // Exponential Moving Average weighting factor
unsigned int I_alpha_1;                         // 1-alpha
unsigned int I_avg;                             // Averaged current
extern unsigned int spindle_amps;               // Binary amps scaled by 10 as integer 100s mA
extern int ADC_amps_new;                        // Flag to signal new measurement available

void run_ADC(){
    if(!ADC_update){                            // If we have reached zero, run ADC for spindle current
        ADC_update=ADC_COUNT;                   // Reload counter              
        AD1CHS0=0b11011;                        // CH0 input from AN27  
        AD1CON1bits.SAMP=1;                     // Start sampling for next ISR      
        while (!AD1CON1bits.DONE);              // Check that conversion has completed        
        I_new=ADC1BUF0;                         // Copy new sample to current variable

        // Exponential Moving Average
        I_avg=((((long)I_new*I_alpha)>>15)+(((long)I_last*I_alpha_1)>>15));
        I_last=I_avg;                           // Update historic record
        
        // Convert to binary value representing 100s mA 
        spindle_amps=(((long)I_avg*AMPS_SCALE)>>15);    
        ADC_amps_new=1;                         // Mark that a new value is available
    }
    ADC_update--;                               // Decrement counter
}

// Initialise ADC
void init_adc(){
    I_alpha=I_ALPHA;                // Current Moving Average weighting factor
    I_alpha_1=I_ALPHA_1;            // 1-I_alpha 
    AD1CON1=0x00E0;                 // Module off, SSRC=1 for TAD based sampling stop
    ANSELBbits.ANSB9 = 1;           // AN27/RB9 is analogue (Spindle Current)
    AD1CHS0=0b011011;               // CH0 input from AN27
    AD1CSSL = 0;                    // 
    AD1CON3 = 0x1F02;               // Sample time = 31Tad, Tad = internal 2 Tcy, ADCS=(75E^-9*40MIPS)-1  
    AD1CON2=0x0000;                 // Vdd/Vss voltage reference, ch0,
    AD1CON1bits.AD12B=1;            // 12 bit operation
    AD1CON1bits.FORM=0;             // Integer
    AD1CON1bits.SSRC=7;             // Manual sample, automatic conversion    
    AD1CON1bits.ADON=1;             // Module on
}
