// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// HD44780 Header File
//
#ifndef LCD_H
#define LCD_H

/* LCD Port Control Bits
 * RC3      RS
 * RC4      RW
 * RC5      E
 * LCD Port Data Bits (Straddles two nibbles on Port B)
 * RB5      DB4
 * RB6      DB5
 * RB7      DB6
 * RB8      DB7
 * 
 * 0 1 2 3 4 5 6 7 8 9 A B C D E F
 * 0 0 0 0 0 1 1 1 1 0 0 0 0 0 0 0 READ     0x01e0
 * 1 1 1 1 1 0 0 0 0 1 1 1 1 1 1 1 WRITE    0xfe1f
 * 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 BF       0x0100
 */ 

// Defines
#define LCD_WRITE 0xfe1f        // LCD port data pins outputs
#define	LCD_READ  0x01e0     	// LCD Port data pins inputs
#define LCD_MASK  0x01e0		// Mask off LCD data
#define LCD_CLR   0xfe1f        // Bit pattern to set port to zero
#define LCD_BF    0x0100        // Busy flag bit position      
#define	LCD_RS	_LATC3			// Register Select
#define	LCD_RW	_LATC4			// Read/Write
#define	LCD_E	_LATC5			// Enable
// Line addresses with DB7 set to indicate DDRAM Address
#define LINE1               0x80          // Line 1 start address
#define LINE2               0xC0          // Line 2 start address
#define LINE3               0x94          // Line 3 start address
#define LINE4               0xD4          // Line 4 start address
//#define cursor_blink        0x0F          // Cursor blink mode
//#define cursor_off          0x0C          // Cursor clear mode
#define CLEAR               0x01          // LCD clear instruction
//#define off                 0x08          // Switch off display
//#define on                  0x0C          // Switch on display
//#define CLEAR_TIME 2000         // Delay in uS for clear command
//#define WRITE_TIME 40           // Delay in uS for write command

// Declarations
extern unsigned char lcd_data;			// Data to and from the LCD
extern unsigned int lcd_mode;			// 1 = character, 0 = instruction
extern unsigned int lcd_bf;             // Busy flag nibble	
extern const int LCD_INIT_STRING[5];    //
// Prototypes
void lcd_busy_check();
int	 lcd_write(unsigned int);
void lcd_chr(unsigned char);
void lcd_ins(unsigned char);
void lcd_str(register const char*);
void init_lcd();
	
#endif