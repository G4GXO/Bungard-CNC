// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Acceleration and Deceleration Ramps
//
// A linear transfer function is used with gradient m and constant c

#include "speed_ramps.h"                    // Header file

unsigned int freq;                          // Spindle drive frequency
unsigned int rpm;                           // Requested Spindle RPM
unsigned int rpm_act;                       // Actual Spindle RPM   

unsigned long phase_factor;                 // Used to speed up phase increment calculation
unsigned int rpm_up;                        // RPM increase flag
unsigned int rpm_down;                      // RPM decrease flag    
int rpm_update;                             // Number of ISR passes per RPM increment/decrement
unsigned int m;                             // V/f gradient
unsigned int c;                             // V/f constant

// Check for speed difference between requested RPM value and actual. If a difference
// is found, set flags for FSM to action change. Rate of change is set coarsely by
// the value of RPM_UPDATE which sets the number of ISR passes between unit RPM steps.

void rpm_chk(){
    if(!rpm_update){                        // Is the update counter at zero?
        if(rpm>rpm_act){                    // Yes, is requested RPM greater than actual?
            rpm_up=1;                       // Set RPM increase flag
            rpm_down=0;                     // Clear decrease flag
        }
        else if(rpm<rpm_act){               // Is requested RPM less than actual?
            rpm_up=0;                       // Clear increase flag    
            rpm_down=1;                     // Set RPM decrease flag
        }
        else{                               // No change
            rpm_up=0;                       //
            rpm_down=0;                     //
        }
        rpm_update=RPM_UPDATE;              // Reload down counter
    }
    rpm_update--;                           // Decrement counter
}

// Pre-compute factors to speed up spindle ramp and V/f calculations
//
// Hz/bit=fs/65536, phase inc = fm*65536/fs, if k=65536/fs then phase inc=fm*k
// to increase resolution at low values of fm, multiply k by 16384 and then
// remove this with a right shift during the phase increment calculation.
// Now k=16384*65536/fs, when multiplied by max freq this is within a 32 bit range.
void init_rpm(){
    phase_factor=((long)16384*65536)/fs;        // Phase factor
    rpm_update=RPM_UPDATE;                      // Load update down counter
    rpm=RPMstart;                               // Show start RPM
    rpm_act=0;                                  //
    
// Compute gradient of linear V/f transform as an integer equation of the form y=mx+c
//
// m is computed from the RPM range and the drive value range. With m calculated, 
// c is derived from y-mx at 60000 RPM. See AN984 for a brief introduction to 
// induction motor V/f curves.    
    m=((32768*(VMAX-VSTART))/(RPMmax-RPMmin));  // V/f gradient
    c=(VMAX-((unsigned long)(RPMmax*m)/32768)); // V/f constant  
}
