// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Buttons Header
//
#ifndef BUTTONS_H
#define BUTTONS_H

#define BUTTON_PORT     PORTB           // Button port
#define BUTTON_MASK     0x0004          // Mask for PORTB buttons
#define BUTTON_CHUCK    PORTBbits.RB2   // Chuck button pin
#define BUTTON_GND      PORTBbits.RB3   // Ground pin for chuck button

// Declarations
extern int button_chuck;                // Chuck button flag
extern int buttons_new;                 // Current button states
extern int buttons_last;                // Previous button states

// Prototypes
void buttons();
void init_buttons();

#endif