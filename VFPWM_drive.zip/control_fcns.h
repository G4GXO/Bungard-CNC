// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Controls Functions Header
//
#ifndef CONTROL_FCNS_H
#define	CONTROL_FCNS_H

// Declarations

// Prototypes
extern int auto_mode();
extern int man_mode();
extern int man_stop();
extern int man_start();
extern int man_idle();
extern int auto_stop();
extern int auto_start();
extern int auto_idle();
extern int man_rpm_inc();
extern int man_rpm_dec();
extern int auto_rpm_inc();
extern int auto_rpm_dec();
extern int spin_up();
extern int spin_down();
extern int chuck_open_man();
extern int chuck_close_man();
extern int chuck_open_auto();
extern int chuck_close_auto();
extern int init_fsm();

#endif	/* CONTROL_FCNS_H */

