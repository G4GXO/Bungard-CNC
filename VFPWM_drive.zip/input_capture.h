// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// PWM Input Capture Header
//
#ifndef INPUT_CAPTURE_H
#define INPUT_CAPTURE_H

// Defines
#define EDGE_ACTIVE 100               // Reset count value for edge detection

// Declarations
extern unsigned int input_dutyCycle;           // Duty cycle of PWM input
extern unsigned int t1;                        // Capture event values
extern unsigned int t2;
extern unsigned int t3;
extern unsigned int edge_det;                  // Counter used to detect PWM edges
extern unsigned int capture_new;               // Flag to mark new result
extern unsigned int ext_rpm;                   // External RPM
extern unsigned int pwm_up;                    // Increase speed flag
extern unsigned int pwm_down;                  // Decrease speed flag

// Prototypes
void pwm_capture();

#endif

