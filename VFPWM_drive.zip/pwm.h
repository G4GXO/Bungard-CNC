// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// PWM Header File
//
#ifndef PWM_H
#define PWM_H

// Current Limit (Amps x 10)
#define IMAX 60         // Limit at 6.0 Amps
#define ISCALE 0x7fff   // Unity scale factor

// Declarations
extern unsigned int drive_phase;        // PWM Sine frequency phase
extern unsigned int drive_phase_inc;    // PWM Sine frequency phase increment
extern int sin_table[256];              // Sine coefficient table
extern unsigned int duty_cycle_scale;   // Scale factor to set sin(x) to available duty cycle range
extern unsigned int duty_cycle_offset;  // Offset to make sine value positive with dead time clearance
extern unsigned int drive_scale;        // PWM scaling (common to all phases)
extern unsigned int Imax;               // Current limit in Amps x 10
extern int          I_scale;            // Current scaling factor
extern int freq_index;                  // Frequency table index

// Prototypes
void pwm_out_en();
void pwm_out_dis();
void init_pwm();
void init_sin_table();


#endif
