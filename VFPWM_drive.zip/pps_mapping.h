// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// PPS Mapping Header File
//
#ifndef PPS_MAPPING_H
#define	PPS_MAPPING_H

// Prototypes
void pin_mapper(void);

#endif	/* PPS_MAPPING_H */

