#ifndef ENCODER_H
#define ENCODER_H

// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Encoder Definitions
//
// Port C
//
// RC0  ENC CH A
// RC1  ENC CH B
// RC2  ENC_SW
//

#define ENC_PORT        PORTC           // Encoder port
#define ENCSCAN_RATE    10              // Run encoder processes once every 10 ISRs to debounce
#define HOLD_COUNT      500             // Count value for normal press and hold
#define LONG_COUNT      1500            // Long hold count
#define VLONG_COUNT     2000            // Very long hold count
#define ENC_SW        PORTCbits.RC2     // Encoder switch
#define ENC_MASK      0x0003            // Encoder channel mask
#define ENC_DIR_BIT   0x0002            // Direction bit

// Declarations
extern unsigned int    encoder_new;    // Current encoder state
extern unsigned int    encoder_last;   // Previous encoder state
extern unsigned int    enc_press;      // Encoder switch press flag
extern unsigned int    enc_press_rel;  // Encoder switch press release
extern unsigned int    enc_hold;       // Encoder hold flag
extern unsigned int    enc_hold_rel;   // Encoder hold release
extern unsigned int    enc_rate;       // Counter to run encoder checks below ISR rate to reduce false states due to contact bounce
extern unsigned int enc_press_mem;     // Press memory flag
extern unsigned int enc_hold_mem;      // Hold memory flag
extern unsigned int    enc_sw_count;   // Switch operated counter
extern unsigned int    enc_dir;        // Direction flag
extern unsigned int    enc_dir_last;   // Historic direction flag
extern unsigned int    enc_up;         // Encoder up flag
extern unsigned int    enc_down;       // Encoder down flag
extern unsigned int    enc_rate;       // Counter to run encoder checks below ISR rate to reduce false states due to contact bounce

// Prototypes
void encoder();
void enc_rel_inhibit();
void init_encoder();

#endif