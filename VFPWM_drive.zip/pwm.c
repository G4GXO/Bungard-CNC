// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// PWM Functions
#include <xc.h>
#include "main.h"
#include "pwm.h"                        // Header file

extern unsigned int drive_phase;        // PWM Sine frequency phase
extern unsigned int drive_phase_inc;    // PWM Sine frequency phase increment
extern int sin_table[256];              // Sine coefficient table
extern unsigned int duty_cycle_scale;   // Scale factor to set sin(x) to available duty cycle range
extern unsigned int duty_cycle_offset;  // Offset to make sine value positive with dead time clearance
extern unsigned int drive_scale;        // PWM scaling (common to all phases)
extern unsigned int Imax;               // Current limit in Amps x 10
extern int          I_scale;            // Current scaling factor

int freq_index;                 // Frequency table index

// Sine Table
// 256 entry table from 0 to 2Pi
const int sin_coeff[256]={
0x0000,	0x0324,	0x0648,	0x096A,	0x0C8C,	0x0FAB,	0x12C8,	0x15E2,	0x18F9,	0x1C0B,		// 	0	-	9
0x1F1A,	0x2223,	0x2528,	0x2826,	0x2B1F,	0x2E11,	0x30FB,	0x33DF,	0x36BA,	0x398C,		//	10	-	19
0x3C56,	0x3F17,	0x41CE,	0x447A,	0x471C,	0x49B4,	0x4C3F,	0x4EBF,	0x5133,	0x539B,		//	20	-	29
0x55F5,	0x5842,	0x5A82,	0x5CB3,	0x5ED7,	0x60EB,	0x62F1,	0x64E8,	0x66CF,	0x68A6,		//	30	-	39
0x6A6D,	0x6C23,	0x6DC9,	0x6F5E,	0x70E2,	0x7254,	0x73B5,	0x7504,	0x7641,	0x776B,		//	40	-	49
0x7884,	0x7989,	0x7A7C,	0x7B5C,	0x7C29,	0x7CE3,	0x7D89,	0x7E1D,	0x7E9C,	0x7F09,		//	50	-	59
0x7F61,	0x7FA6,	0x7FD8,	0x7FF5,	0x7FFF,	0x7FF5,	0x7FD8,	0x7FA6,	0x7F61,	0x7F09,		//	60	-	69
0x7E9C,	0x7E1D,	0x7D89,	0x7CE3,	0x7C29,	0x7B5C,	0x7A7C,	0x7989,	0x7884,	0x776B,		//	70	-	79
0x7641,	0x7504,	0x73B5,	0x7254,	0x70E2,	0x6F5E,	0x6DC9,	0x6C23,	0x6A6D,	0x68A6,		//	80	-	89
0x66CF,	0x64E8,	0x62F1,	0x60EB,	0x5ED7,	0x5CB3,	0x5A82,	0x5842,	0x55F5,	0x539B,		//	90	-	99
0x5133,	0x4EBF,	0x4C3F,	0x49B4,	0x471C,	0x447A,	0x41CE,	0x3F17,	0x3C56,	0x398C,		//	100	-	109
0x36BA,	0x33DF,	0x30FB,	0x2E11,	0x2B1F,	0x2826,	0x2528,	0x2223,	0x1F1A,	0x1C0B,		//	110	-	119
0x18F9,	0x15E2,	0x12C8,	0x0FAB,	0x0C8C,	0x096A,	0x0648,	0x0324,	0x0000,	0xFCDC,		//	120	-	129
0xF9B8,	0xF696,	0xF374,	0xF055,	0xED38,	0xEA1E,	0xE707,	0xE3F5,	0xE0E6,	0xDDDD,		//	130	-	139
0xDAD8,	0xD7DA,	0xD4E1,	0xD1EF,	0xCF05,	0xCC21,	0xC946,	0xC674,	0xC3AA,	0xC0E9,		//	140	-	149
0xBE32,	0xBB86,	0xB8E4,	0xB64C,	0xB3C1,	0xB141,	0xAECD,	0xAC65,	0xAA0B,	0xA7BE,		//	150	-	159
0xA57E,	0xA34D,	0xA129,	0x9F15,	0x9D0F,	0x9B18,	0x9931,	0x975A,	0x9593,	0x93DD,		//	160	-	169
0x9237,	0x90A2,	0x8F1E,	0x8DAC,	0x8C4B,	0x8AFC,	0x89BF,	0x8895,	0x877C,	0x8677,		//	170	-	179
0x8584,	0x84A4,	0x83D7,	0x831D,	0x8277,	0x81E3,	0x8164,	0x80F7,	0x809F,	0x805A,		//	180	-	189
0x8028,	0x800B,	0x8001,	0x800B,	0x8028,	0x805A,	0x809F,	0x80F7,	0x8164,	0x81E3,		//	190	-	199
0x8277,	0x831D,	0x83D7,	0x84A4,	0x8584,	0x8677,	0x877C,	0x8895,	0x89BF,	0x8AFC,		//	200	-	209
0x8C4B,	0x8DAC,	0x8F1E,	0x90A2,	0x9237,	0x93DD,	0x9593,	0x975A,	0x9931,	0x9B18,		//	210	-	219
0x9D0F,	0x9F15,	0xA129,	0xA34D,	0xA57E,	0xA7BE,	0xAA0B,	0xAC65,	0xAECD,	0xB141,		//	220	-	229
0xB3C1,	0xB64C,	0xB8E4,	0xBB86,	0xBE32,	0xC0E9,	0xC3AA,	0xC674,	0xC946,	0xCC21,		//	230	-	239
0xCF05,	0xD1EF,	0xD4E1,	0xD7DA,	0xDAD8,	0xDDDD,	0xE0E6,	0xE3F5,	0xE707,	0xEA1E,		//	240	-	249
0xED38,	0xF055,	0xF374,	0xF696,	0xF9B8,	0xFCDC,                             		//	250	-	256
};

//------------------------------------------------------------------------------
// PWM Pin Overrides
void pwm_out_en(){              // Pass control of output pins to PWM module
//P1OVDCON = 0xff00;              // Pins under PWM module control      
}

void pwm_out_dis(){             // Pass control of output pins to P1VDCON register
//P1OVDCON = 0x0000;              // PWM off, outputs low        
}
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
//
// PWM Initialise
//
// Configure PWM1 module for common period and independent duty cycles. This
// us to define the phase relationship between the three phases from sine lookup
// using 120 degree phase shifts. The primary timebase is set for 20kHz PWM.
//------------------------------------------------------------------------------
void init_pwm(){                // Initialise PWM1 Module for three phase operation
// Note! PMWLOCK is set to OFF to allow write to protected registers without using 
// the EEPROM unlock sequence.   
//
// PWM time period based on input clock selected. Refer to Equation 14.7.1 in High 
// Speed PWM section of the dsPIC33E FRM. For a PWM Period of 20kHz at 70MIPS, Fosc 
// is 140MHz and P1TPER=Fosc/(Fpwm*PWM Prescaler)
//    
// With prescaler set to 1, PTPER = 140E6/(20E3*1 = 7000. The Special Event Timer
// is loaded with the same period to trigger an interrupt on each PWM period. The
// ISR computes the next duty cycle and amplitude parameter set and loads it ready
// for the next PWM period.    

PTPER = 11666;//7000;           // PWM timebase value for 20kHz
PTCONbits.SEVTPS = 0;           // Special Event Trigger output postscaler set to 1:1 selection    
SEVTCMP=20;                     // Special Event Timer count
IOCON4=0x0000;                  // PWM4 H&L Outputs assigned to GPIO (RA7,RA10)
IOCON6=0x0000;                  // PWM6 H&L Outputs assigned to GPIO (RC6,RC7)
// LCD Negative Contrast Voltage Generator (PWM5, output on Low side only - RC9)
PDC5 = 1024;                    // LCD Negative Voltage Generator Duty Cycle (Sets contrast)
PHASE5 = 0;                     // No phase shift
DTR5 = 140;                     // Nominal Dead time
PWMCON5 = 0x0000;               //
IOCON5 = 0x4000;                // Only low side output used, high is under GPIO control (RC8)
FCLCON5 = 0x0003;               // Fault inputs disabled

// 3-Phase Spindle Drive (PWM1..PWM3)
//
// Phase shift between output channels is controlled by the phase accumulator in the ISR.
// The phase registers are used as the time base and are set to half the period count.
// (See dsPIC33E High Speed PWM figure 14.22)
PHASE1 = 5833;//3500;
PHASE2 = 5833;//3500;
PHASE3 = 5833;//3500;

// Duty Cycle is set by sine value from lookup table and amplitude scaling. Set the 
// duty cycle registers to zero.
PDC1 = 0;
PDC2 = 0;
PDC3 = 0;

// Dead Time is common to all phases and leading and trailing edges. At 140MHz clock
// the resolution is 7.14nsec. For 1usec deadtime and prescaler set to 1 this gives 
// a counter value of 140 (Deadtime=Fosc*Deadtime/PWM Prescaler)
//
// DTR registers are ignored in complementary mode, use Alternative set
DTR1 = 0;
DTR2 = 0;
DTR3 = 0;

ALTDTR1 = 25;
ALTDTR2 = 25;
ALTDTR3 = 25;

// Set PWM Mode to Complementary
IOCON1 = 0xC000;
IOCON2 = 0xC000;   
IOCON3 = 0xC000;

// Set Phase Reg as Time Base, Centre-Aligned Mode, Faults off and Independent Duty Cycles 
PWMCON1 = 0x0204;
PWMCON2 = 0x0204;
PWMCON3 = 0x0204;

// Configure Faults
FCLCON1 = 0x0003;
FCLCON2 = 0x0003;
FCLCON3 = 0x0003;

// Set prescaler to 1:1 
PTCON2 = 0x0000;

// Enable PWM Module
PTCON = 0x8000;

pwm_out_dis();                  // Keep outputs low for now

// PWM Duty Cycle Amplitude Scaling 
//
// Set scaling factor for 100% duty cycle sine modulation allowing for dead time, at PWM period
// In centre aligned mode the phase value sets period and is equal to half of the period count as
// the alignment process uses the count to count up and then down with the transition point being
// centre period. The duty cycle duration count also operates this way and equals half PWM period 
// less the dead time. The peak amplitude of the sine wave will be half of the available duty cycle
// range. This is made up of half of the phase count less the dead time. The resulting value is used
// to scale the sine table values to fit the the duty cycle range. As the sine table values are
// positive and negative going, the scaled values need to be offset such that the zero transition 
// point sits mid duty cycle range, (between zero plus dead time and phase/2 less dead time). This 
// prevents the duty cycle range from being exceeded causing errors in the sine output.
//
duty_cycle_scale=(PHASE1>>1)-ALTDTR1;   // Scale sine look ups to this value for maximum duty cycle period
duty_cycle_offset=PHASE1>>1;            // Offset to lift sine duty cycle into positive value with clearance
                                        // for dead time at minimum range
                                        // (See dsPIC33E High Speed PWM fig 14.21)

// Current limit
//
// Load maximum current value into Imax for use by the modulator
Imax=IMAX;                              // Load current limit
I_scale=ISCALE;                         // Set scaling factor to 0.999
}

// Sin table hold a full fractional range sine wave. This is used by the modulator to produce a
// PWM duty cycle which is amplitude modulated by the V/f parameter and scaled and shifted so as 
// to form a positive duty cycle value that falls within the 100% maximum value less dead time. 

void init_sin_table(){
    int i;
    for(i=0;i<256;i++){                 // Load sine coefficients into working table
        sin_table[i]=sin_coeff[i];      //
    }
}

