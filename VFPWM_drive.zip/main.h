// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Main Header File
//
//
// Port and Pin Allocations
/*
 * PORT A   DIR     P/U     FCN
 * RA0      0               CHUCK CONTROL OUTPUT                
 * RA1      0               CHUCK CONTROL OUTPUT (GND)
 * RA2      0               OUTPUT LOW FOR ENCODER COMMON
 * RA3      0   0           
 * RA4      1               
 * RA7      1   f
 * RA8      1                  
 * RA9      1               
 * RA10     1   f            
 * 
 * PORT B   DIR     P/U     FCN
 * RB0      1               PGED1
 * RB1      1               PGEC1
 * RB2      1               CHUCK BUTTON
 * RB3      0   f           CHUCK BUTTON (GND)
 * RB4      1               PWM Input For Spindle Speed
 * RB5      0               LCD 4
 * RB6      0               LCD 5
 * RB7      0   1           LCD 6
 * RB8      0               LCD 7
 * RB9      1               Spindle Current Sense               
 * RB10     0               PWM1H3
 * RB11     0   2           PMW1L3
 * RB12     0               PMW1H2
 * RB13     0               PWM1L2
 * RB14     0               PMW1H1
 * RB15     0   0           PWM1L1
 * 
 * PORT C   DIR     P/U     FCN
 * RC0      1               ENC_A
 * RC1      1               ENC_B
 * RC2      1               ENC_SW
 * RC3      0   7           LCD_RS
 * RC4      0               LCD_RW 
 * RC5      0               LCD_E
 * RC6      0               
 * RC7      0   0
 * RC8      0               
 * RC9      0               LCD Negative Voltage Generator             
 * RC10     1
 * RC11     1   c
 * RC12     1    
 * RC13     1
 * RC14     1
 * RC15     1   f
 * 
 */
#ifndef MAIN_H
#define	MAIN_H

#define FOSC    140000000UL
#define FCY     FOSC/2

// Port 
#define PORTA_DIR   0xfff0      // Port A TRIS Bits
#define PORTB_DIR   0x0217      // Port B TRIS Bits
#define PORTC_DIR   0xfc07      // Port C TRIS Bits

// Weak Pull Ups
#define WEAK_PUA    0x0118      // Port A weak pull ups (Buttons)
#define WEAK_PUB    0x0004      // Port B weak pull ups 
#define WEAK_PUC    0x0007      // Port C weak pull ups (Encoder)

// Open Drains
#define PORTA_OD    0x0000      // Open Drains Port A
#define PORTB_OD    0x0000      // Open Drains Port B
#define PORTC_OD    0x0000      // Open Drains Port C 

// Peripheral Disable
#define PMD1DIS     0x05fe   
#define PMD2DIS     0x00ff
#define PMD3DIS     0x0eee
#define PMD4DIS     0xffff
#define PMD6DIS     0x0001
#define PMD7DIS     0xffff


// Prototypes
int main();

#endif	/* MAIN_H */
