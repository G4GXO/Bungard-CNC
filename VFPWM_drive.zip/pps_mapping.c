// VFPWM Spindle Driver
//
// (c)Ron Taylor
//
// Peripheral Pin Mapping
//
#include <xc.h>
#include "main.h"
#include "pps_mapping.h"

// Pin Mapper assigns peripherals to physical I/O pins to match PCB assignment
// See data sheet for pin register names, peripheral names and values.

void pin_mapper(void){
//******************************************************************************
// Unlock Peripheral Pin Select Registers
// To set or clear the IOLOCK bit, a specific command sequence must be executed:
// 1.Write 0x46 to OSCCON<7:0>
// 2.Write 0x57 to OSCCON<7:0>
// 3.Clear (or set) IOLOCK as a single operation
//
// The macros shown perform the unlock and lock sequence. The equivalent code
// is shown after each macro.
//
//******************************************************************************
    __builtin_write_OSCCONL(OSCCON & ~(1<<6));

//    __asm("mov #OSCCONL, w1");  // Load OSCCONL address into w1
//    __asm ("mov #0x46, w2");    // Load 0x46 into w2
//    __asm ("mov #0x57, w3");    // Load 0x57 into w3
//    __asm ("mov.b w2, [w1]");   // Write 0x46 byte to OSCCONL
//    __asm ("mov.b w3, [w1]");   // Write 0x57 byte to OSCCONL
//    OSCCONbits.IOLOCK=0;
//
// Input Pin Mapping
//
// To map a pin to the input of a peripheral, first identify the corresponding
// RPIN register for the peripheral in the data sheet. Next look up the input
// pin assignment address for the chosen physical pin, and finally assign this
// to the RPIN register.
//
// E.g. To connect the DCI input physical pin 63 we first look up the address of
// the CSDI in the data sheet which shows it as being within PPS register RPIN24.
// We define this as the peripheral that we want to use by the setting the register
// bits like this; RPIN24bits.CSDIR
// Next we need to define the address of the pin that we want to use as the input
// to this peripheral. We do this by looking up the input pin assignment address
// in the data sheet, for pin 63 this is address RP83 (83d or 0x53). The pin is
// now assigned to the DCI input by adding it's address to the peripheral as follows;
// RPIN24bits.CSDIR=83;
//
// Output Pin Mapping
//
// Mapping a peripheral output to pin is done from the perspective of the output pin.
// First we define the pin that we want to use as an output (it must be a pin that
// is usable as an output or I/O pin). Next we look up it PPS register address in
// the data sheet. Finally we assign the peripheral output to the pin, this is done
// by assigning the peripheral output selection address shown in the data sheet.
//
// E.g. To assign CSDO the DCI data output to pin 64, we identify the pin
// address from the data sheet as belonging to register RPOR5. To specify pin 64
// we set the register bit by adding the RP address of the pin, in this case RP84.
// The code now looks like; RPOR5bits.RP84R
// Finally we assign the peripheral output to this pin by assigning the output
// selection address for the peripheral (again in the data sheet), in this case
// 0x0b. The final code is now; RPOR5bits.RP84R=0x0b;
//
// Check the device header file for valid port and peripheral names.

// Define Input Compare Pin Assignments
    // Inputs
    RPINR7 = 36;           // Assign IC1 to RP36 (pin 33, RB4)

//******************************************************************************
// Lock Peripheral Pin Select Registers
//******************************************************************************
__builtin_write_OSCCONL(OSCCON | (1<<6));

//    __asm("mov #OSCCONL, w1");  // Load OSCCONL address into w1
//    __asm ("mov #0x46, w2");    // Load 0x46 into w2
//    __asm ("mov #0x57, w3");    // Load 0x57 into w3
//    __asm ("mov.b w2, [w1]");   // Write 0x46 byte to OSCCONL
//    __asm ("mov.b w3, [w1]");   // Write 0x57 byte to OSCCONL
//    OSCCONbits.IOLOCK=1;
}




